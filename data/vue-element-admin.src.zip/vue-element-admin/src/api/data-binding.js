import request from '@/utils/request'

export function fetchDataBindingList(query) {
  return request({
    url: '/vue-element-admin/data-binding/list',
    method: 'get',
    params: query
  })
}

export function fetchDataBinding(id) {
  return request({
    url: `/vue-element-admin/data-binding/${id}`,
    method: 'get'
  })
}

export function fetchDataBindingByTemplateId(templateId) {
  return request({
    url: `/vue-element-admin/data-binding/list?templateId=${templateId}`,
    method: 'get'
  })
}

export function createDataBinding(data) {
  return request({
    url: '/vue-element-admin/data-binding',
    method: 'post',
    data
  })
}

export function updateDataBinding(data) {
  return request({
    url: '/vue-element-admin/data-binding',
    method: 'put',
    data
  })
}

export function deleteDataBinding(id) {
  return request({
    url: `/vue-element-admin/data-binding/${id}`,
    method: 'delete'
  })
}
