import request from '@/utils/request'

export function fetchDictionaryList(query) {
  return request({
    url: '/vue-element-admin/dictionary/list',
    method: 'get',
    params: query
  })
}

export function fetchDictionary(id) {
  return request({
    url: `/vue-element/dictionary/${id}`,
    method: 'get'
  })
}

export function createDictionary(data) {
  return request({
    url: '/vue-element-admin/dictionary',
    method: 'post',
    data
  })
}

export function updateDictionary(data) {
  return request({
    url: '/vue-element-admin/dictionary',
    method: 'put',
    data
  })
}

export function deleteDictionary(id) {
  return request({
    url: `/vue-element-admin/dictionary/${id}`,
    method: 'delete'
  })
}
