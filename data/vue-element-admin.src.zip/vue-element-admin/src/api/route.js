import request from '@/utils/request'

export function getRouteTree() {
  return request({
    url: '/vue-element-admin/route/routes',
    method: 'get'
  })
}

export function getRoutes() {
  return request({
    url: '/vue-element-admin/route/list',
    method: 'get'
  })
}

export function getRoute(id) {
  return request({
    url: `/vue-element-admin/route/${id}`,
    method: 'get'
  })
}

export function addRoute(data) {
  return request({
    url: '/vue-element-admin/route',
    method: 'post',
    data
  })
}

export function updateRoute(data) {
  return request({
    url: '/vue-element-admin/route',
    method: 'put',
    data
  })
}

export function deleteRoute(id) {
  return request({
    url: `/vue-element-admin/route/${id}`,
    method: 'delete'
  })
}
