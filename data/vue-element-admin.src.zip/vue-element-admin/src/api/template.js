import request from '@/utils/request'

export function fetchTemplateList(query) {
  return request({
    url: '/vue-element-admin/template/list',
    method: 'get',
    params: query
  })
}

export function fetchTempalte(id) {
  return request({
    url: `/vue-element-admin/template/${id}`,
    method: 'get'
  })
}

export function createTemplate(data) {
  return request({
    url: '/vue-element-admin/template',
    method: 'post',
    data
  })
}

export function updateTemplate(data) {
  return request({
    url: '/vue-element-admin/template',
    method: 'put',
    data
  })
}

export function deleteTemplate(id) {
  return request({
    url: `/vue-element-admin/template/${id}`,
    method: 'delete'
  })
}

export function updateTemplateEditor(data) {
  return request({
    url: '/vue-element-admin/template/editor',
    method: 'put',
    data
  })
}

export function downloadTemplatePdf(id) {
  return request({
    url: `/vue-element-admin/template/download/${id}`,
    method: 'get'
  })
}

export function fetchTemplateFolderList(query) {
  return request({
    url: '/vue-element-admin/template-folder/list',
    method: 'get',
    params: query
  })
}

export function fetchTemplateFolder(id) {
  return request({
    url: `/vue-element-admin/template-folder/${id}`,
    method: 'get'
  })
}

export function fetchTemplateFolderByMarket(market) {
  return request({
    url: `/vue-element-admin/template-folder/list?market=${market}`,
    method: 'get'
  })
}

export function createTemplateFolder(data) {
  return request({
    url: '/vue-element-admin/template-folder',
    method: 'post',
    data
  })
}

export function updateTemplateFolder(data) {
  return request({
    url: '/vue-element-admin/template-folder',
    method: 'put',
    data
  })
}

export function deleteTemplateFolder(id) {
  return request({
    url: `/vue-element-admin/template-folder/${id}`,
    method: 'delete'
  })
}
