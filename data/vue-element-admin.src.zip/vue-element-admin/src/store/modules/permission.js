import { constantRoutes } from '@/router'
import { getRouteTree } from '@/api/route'
import Layout from '@/layout'
/**
 * Use meta.role to determine if the current user has permission
 * @param roles
 * @param route
 */
function hasPermission(roles, route) {
  if (route.meta && route.meta.roles) {
    return roles.some(role => route.meta.roles.includes(role))
  } else {
    return true
  }
}

/**
 * Filter asynchronous routing tables by recursion
 * @param routes asyncRoutes
 * @param roles
 */
export function filterAsyncRoutes(routes, roles) {
  const res = []

  routes.forEach(route => {
    const tmp = { ...route }
    // alert(tmp.component)
    if (tmp.component) {
      if (tmp.component === 'Layout') {
        tmp.component = Layout
      } else {
        tmp.component = loadView(tmp.component)
      }
    }
    if (hasPermission(roles, tmp)) {
      if (tmp.children) {
        tmp.children = filterAsyncRoutes(tmp.children, roles)
      }
      res.push(tmp)
    }
  })

  return res
}

export const loadView = view => {
  return resolve => require(['@/views/' + view], resolve)
}

export function findRouteTree() {
  const res = []
  getRouteTree().then(resp => {
    resp.data.items.forEach(route => {
      res.push(route)
    })
    // alert('m-p-f ' + JSON.stringify(res))
    return res
  })
}

const state = {
  routes: [],
  addRoutes: []
}

const mutations = {
  SET_ROUTES: (state, routes) => {
    state.addRoutes = routes
    state.routes = constantRoutes.concat(routes)
  }
}

const actions = {
  generateRoutes({ commit }, roles) {
    // const { resp } = getRouteTree()
    // const { tmp } = findRouteTree()
    // alert('m-p1 ' + JSON.stringify(tmp))
    // alert('m-p2 ' + JSON.stringify(roles))
    // const dynamicRoutes = resp.data.items
    // getRouteTree().then(resp => {
    //   dynamicRoutes = resp.data.items
    // })
    // alert('m-p3 ' + JSON.stringify(dynamicRoutes))
    return new Promise(resolve => {
      getRouteTree().then(resp => {
        const dRoutes = resp.data.items
        // alert('mpp-1 ' + JSON.stringify(dRoutes))
        const accessedRoutes = filterAsyncRoutes(dRoutes, ['admin'])
        // alert('mpp-2 ' + JSON.stringify(accessedRoutes))
        commit('SET_ROUTES', accessedRoutes)
        resolve(accessedRoutes)
      })
      // if (roles.includes('admin')) {
      //   accessedRoutes = asyncRoutes || []
      // } else {
      //   accessedRoutes = filterAsyncRoutes(asyncRoutes, roles)
      // }
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
