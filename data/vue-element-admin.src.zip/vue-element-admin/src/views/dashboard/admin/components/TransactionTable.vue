<template>
  <el-table :data="list" style="width: 100%;padding-top: 15px;">
    <el-table-column label="OPPM" min-width="200">
      <template slot-scope="scope">
        {{ scope.row.oppm }}
      </template>
    </el-table-column>
    <el-table-column label="Market" width="195" align="center">
      <template slot-scope="scope">
        {{ scope.row.market }}
      </template>
    </el-table-column>
    <el-table-column label="Status" width="100" align="center">
      <template slot-scope="{row}">
        <el-tag :type="row.status | statusFilter">
          {{ row.status }}
        </el-tag>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import { fetchTemplateList } from '@/api/template'

export default {
  filters: {
    statusFilter(status) {
      const statusMap = {
        Published: 'success',
        Draft: 'info',
        Progress: 'warning',
        Deleted: 'danger',
        Released: 'success'
      }
      return statusMap[status]
    },
    orderNoFilter(str) {
      return str.substring(0, 30)
    }
  },
  data() {
    return {
      list: null
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    fetchData() {
      fetchTemplateList().then(response => {
        this.list = response.data.items.slice(0, 8)
      })
    }
  }
}
</script>
