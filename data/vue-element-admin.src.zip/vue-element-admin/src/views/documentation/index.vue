<template>
  <div class="app-container documentation-container">
    <a class="document-btn" target="_blank" href="/article/documentations">System Usage Docs</a>
    <a class="document-btn" target="_blank" href="/article/mockup-quick-start">Quick Start</a>
    <dropdown-menu class="document-btn" :items="articleList" title="Dev Series" />
    <a class="document-btn" target="_blank" href="/article/others">Others</a>
  </div>
</template>

<script>
import DropdownMenu from '@/components/Share/DropdownMenu'

export default {
  name: 'Documentation',
  components: { DropdownMenu },
  data() {
    return {
      articleList: [
        { title: 'Quick Start', href: '/article/dev-series/quick-start' },
        { title: 'Environment', href: '/article/dev-series/environment' },
        { title: 'Frontend', href: '/article/dev-series/frontend' },
        { title: 'Backend', href: '/article/dev-series/backend' },
        { title: 'Menus & Routes', href: '/article/dev-series/routes' },
        { title: 'Authorization', href: '/article/dev-series/authorization' },
        { title: 'Authentication', href: '/article/dev-series/authentication' }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
.documentation-container {
  margin: 50px;
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-start;

  .document-btn {
    flex-shrink: 0;
    display: block;
    cursor: pointer;
    background: black;
    color: white;
    height: 60px;
    padding: 0 16px;
    margin: 16px;
    line-height: 60px;
    font-size: 20px;
    text-align: center;
  }
}
</style>
