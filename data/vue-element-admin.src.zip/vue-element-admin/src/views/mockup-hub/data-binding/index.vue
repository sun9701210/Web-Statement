<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input v-model="listQuery.name" placeholder="Name" style="width: 200px" class="filter-item" @keyup.enter.native="handleFilter" />
      <el-select v-model="listQuery.sort" style="margin-left: 10px;width: 140px;" class="filter-item" @change="handleFilter">
        <el-option v-for="item in sortOptions" :key="item.key" :label="item.label" :value="item.key" />
      </el-select>
      <el-button v-waves style="margin-left: 10px;" class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">Search</el-button>
      <el-button v-waves :loading="downloadLoading" class="filter-item" type="primary" icon="el-icon-download" @click="handleDownload">Export</el-button>
    </div>

    <el-table
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%;"
      @sort-change="sortChange"
    >
      <el-table-column label="ID" prop="id" sortable="custom" align="center" min-width="10" :class-name="getSortClass('id')">
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Placeholder" prop="placeholder" align="left" header-align="center" min-width="20">
        <template slot-scope="{row}">
          <el-tag style="margin-right: 5px">{{ row.dictionary.source | sourceFilter }}</el-tag>
          <span class="link-type" @click="handleUpdate(row)">{{ row.placeholder }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Binding Type" prop="bindingType" align="center" min-width="20">
        <template slot-scope="{row}">
          <span>{{ row.bindingType }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Process Class Name" prop="processClassName" align="center" min-width="20">
        <template slot-scope="{row}">
          <span>{{ row.processClassName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Binding Dictionary" prop="dictionary.name" align="center" min-width="20">
        <template slot-scope="{row}">
          <span>{{ row.dictionary.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Binding Template" prop="template.name" align="center" min-width="20">
        <template slot-scope="{row}">
          <span>{{ row.template.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Actions" header-align="center" align="center" min-width="30" class-name="big-padding fixed-width">
        <template slot-scope="{row, $index}">
          <el-button type="primary" size="mini" @click="handleUpdate(row)">Edit</el-button>
          <el-button v-if="row.status!='Deleted'" size="mini" type="danger" @click="handleDelete(row, $index)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />

    <el-tooltip placement="top" content="Back to Top">
      <back-to-top :custom-style="myBackToTopStyle" :visibility-height="300" :back-position="50" transition-name="fade" />
    </el-tooltip>

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="temp" label-position="right" label-width="110px" style="margin-left: 50px;">
        <el-form-item label="Placeholder" prop="placeholder">
          <el-input v-model="temp.placeholder" placeholder="please enter placeholder" />
        </el-form-item>
        <el-form-item label="Dictionary" prop="dictionary">
          <el-select v-model="temp.dictionary.id" class="filter-item" placeholder="Please select dictionary" @change="handleDictionaryChangeInUpdate">
            <el-option v-for="item in dictionaryList" :key="item.id" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="Template" prop="template">
          <el-select v-model="temp.template.id" class="filter-item" placeholder="Please select template" @change="handleTemplateChangeInUpdate">
            <el-option v-for="item in templateList" :key="item.id" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">Confirm</el-button>
        <el-button @click="dialogFormVisible=false">Cancel</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { createDataBinding, deleteDataBinding, fetchDataBindingList, updateDataBinding } from '@/api/data-binding'
import { fetchDictionaryList } from '@/api/dictionary'
import { fetchTemplateList } from '@/api/template'
import Pagination from '@/components/Pagination'
import BackToTop from '@/components/BackToTop'
import waves from '@/directive/waves/waves'

const supportSourceOptions = [
  { key: 'AM', display_name: 'ALS' },
  { key: 'IM', display_name: 'Impacts' },
  { key: 'AV', display_name: 'Advice' },
  { key: 'MF', display_name: 'Mutual Fund' },
  { key: 'FG', display_name: 'FG' },
  { key: 'FT', display_name: 'Fund Transfer' },
  { key: 'IP', display_name: 'IP' },
  { key: 'IT', display_name: 'IT' },
  { key: 'MD', display_name: 'MD' },
  { key: 'MX', display_name: 'MX' },
  { key: 'RM', display_name: 'Reln Mgmt' }
]

const supportSourceKeyValue = supportSourceOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

export default {
  name: 'DataBindingManagement',
  components: { Pagination, BackToTop },
  directives: { waves },
  filters: {
    sourceFilter(source) {
      return supportSourceKeyValue[source]
    }
  },
  myBackToTopStyle: {
    right: '50px',
    bottom: '50px',
    width: '40px',
    height: '40px',
    'border-radius': '4px',
    'line-height': '45px', // 请保持与高度一致以垂直居中 Please keep consistent with height to center vertically
    background: '#e7eaf1'// 按钮的背景颜色 The background color of the button
  },
  data() {
    return {
      listLoading: true,
      listQuery: {
        name: undefined,
        page: 1,
        limit: 20,
        dictionary: undefined,
        template: undefined,
        sort: '+id'
      },
      list: null,
      dictionaryList: [],
      selectedBindingDictionary: '',
      templateList: null,
      total: 0,
      sortOptions: [{ label: 'ID Ascending', key: '+id' }, { label: 'ID Descending', key: '-id' }],
      temp: {
        id: undefined,
        placeholder: undefined,
        bindingType: undefined,
        processClassName: undefined,
        dictionary: { id: 0 },
        template: { id: 0 }
      },
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      rules: {
        name: [{ required: true, message: 'name is required', trigger: 'blur' }]
      }
    }
  },
  created() {
    this.getList()
    this.getTemplateList()
    this.getDictionaryList()
  },
  methods: {
    getList() {
      this.listLoading = true
      fetchDataBindingList(this.listQuery).then(resp => {
        this.list = resp.data.items
        this.total = resp.data.total

        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 1000)
      })
    },
    getTemplateList() {
      fetchTemplateList(null).then(resp => {
        this.templateList = resp.data.items
      })
    },
    getDictionaryList() {
      fetchDictionaryList(null).then(resp => {
        this.dictionaryList = resp.data.items
      })
    },
    getSortClass: function(key) {
      const sort = this.listQuery.sort
      return sort === `+${key}` ? 'ascending' : 'descending'
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    sortByID(order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    sortChange(data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        placeholder: undefined,
        bindingType: undefined,
        processClassName: undefined,
        dictionary: { id: 0 },
        template: { id: 0 }
      }
    },
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          this.temp.id = parseInt(Math.random() * 100) + 1024 // mock an id
          createDataBinding(this.temp).then(resp => {
            this.temp.id = resp.data.id
            this.list.unshift(this.temp)
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Created Successfully',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row) // copy obj
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    handleDictionaryChangeInUpdate(dictionaryId) {
      this.dictionaryList.forEach((item) => {
        if (item.id === dictionaryId) {
          this.temp.dictionary = item
        }
      })
    },
    handleTemplateChangeInUpdate(templateId) {
      this.templateList.forEach((item) => {
        if (item.id === templateId) {
          this.temp.template = item
        }
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          updateDataBinding(tempData).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Update Successfully',
              type: 'success',
              duration: 5000
            })
            this.$nextTick(() => {
              this.$refs['dataForm'].clearValidate()
            })
          })
        }
      })
    },
    handleDelete(row, index) {
      deleteDataBinding(row.id).then(resp => {
        this.$notify({
          title: 'Success',
          message: 'Deleted Successfully',
          type: 'success',
          duration: 5000
        })
        this.list.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped>

</style>
