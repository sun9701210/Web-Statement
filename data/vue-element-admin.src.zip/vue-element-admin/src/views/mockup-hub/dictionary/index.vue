<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input v-model="listQuery.name" placeholder="Name" style="width: 200px" class="filter-item" @keyup.enter.native="handleFilter" />
      <el-select v-model="listQuery.category" placeholder="Category" clearable class="filter-item" style="margin-left: 10px;width: 130px;">
        <el-option v-for="item in supportCategoryOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
      </el-select>
      <el-select v-model="listQuery.source" placeholder="Source" clearable class="filter-item" style="margin-left: 10px;width: 130px;">
        <el-option v-for="item in supportSourceOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
      </el-select>
      <el-select v-model="listQuery.type" placeholder="Type" clearable style="margin-left: 10px;width: 100px;" class="filter-item">
        <el-option v-for="item in supportTypeOptions" :key="item" :label="item.display_name+'('+item.key+')'" :value="item.key" />
      </el-select>
      <el-select v-model="listQuery.sort" style="margin-left: 10px;width: 140px;" class="filter-item" @change="handleFilter">
        <el-option v-for="item in sortOptions" :key="item.key" :label="item.label" :value="item.key" />
      </el-select>
      <el-button v-waves style="margin-left: 10px;" class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">Search</el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="handleCreate">Add</el-button>
      <el-button v-waves :loading="downloadLoading" class="filter-item" type="primary" icon="el-icon-download" @click="handleDownload">Export</el-button>
    </div>
    <div>
      <el-header>Current Source - {{ listQuery.source }}</el-header>
    </div>

    <el-table
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%;"
      @sort-change="sortChange"
    >
      <el-table-column label="ID" prop="id" sortable="custom" align="center" min-width="5" :class-name="getSortClass('id')">
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Name" prop="name" align="left" header-align="center" min-width="25">
        <template slot-scope="{row}">
          <el-tag style="margin-right: 5px">{{ row.source | sourceFilter }}</el-tag>
          <span class="link-type" @click="handleUpdate(row)">{{ row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Category" prop="category" align="center" min-width="20">
        <template slot-scope="{row}">
          <span>{{ row.category | categoryFilter }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Source" prop="source" align="center" min-width="5">
        <template slot-scope="{row}">
          <span>{{ row.source }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Type" prop="type" align="center" min-width="7">
        <template slot-scope="{row}">
          <span>{{ row.type }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Default Value" prop="defaultValue" align="center" min-width="12">
        <template slot-scope="{row}">
          <span>{{ row.defaultValue }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Format" prop="format" align="center" min-width="8">
        <template slot-scope="{row}">
          <span>{{ row.format }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Description" prop="description" align="center" min-width="18">
        <template slot-scope="{row}">
          <span>{{ row.description }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Actions" header-align="center" align="center" min-width="20" class-name="big-padding fixed-width">
        <template slot-scope="{row, $index}">
          <el-button type="primary" size="mini" @click="handleUpdate(row)">Edit</el-button>
          <el-button v-if="row.status!='Deleted'" size="mini" type="danger" @click="handleDelete(row, $index)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />

    <el-tooltip placement="top" content="Back to Top">
      <back-to-top :custom-style="myBackToTopStyle" :visibility-height="300" :back-position="50" transition-name="fade" />
    </el-tooltip>

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="temp" label-position="right" label-width="110px" style="width: 400px; margin-left: 50px;">
        <el-form-item label="Name" prop="name">
          <el-input v-model="temp.name" placeholder="please enter name" />
        </el-form-item>
        <el-form-item label="Type" prop="type">
          <el-select v-model="temp.type" class="filter-item" placeholder="Please select">
            <el-option v-for="item in supportTypeOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item label="Category" prop="category">
          <el-select v-model="temp.category" class="filter-item" placeholder="Please select">
            <el-option v-for="item in supportCategoryOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item label="Source" prop="source">
          <el-select v-model="temp.source" class="filter-item" placeholder="Please select">
            <el-option v-for="item in supportSourceOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item label="Format" prop="format">
          <el-input v-model="temp.format" type="text" :rows="3" placeholder="Please enter format" />
        </el-form-item>
        <el-form-item label="Default Value" prop="defaultValue">
          <el-input v-model="temp.defaultValue" type="text" :rows="3" placeholder="Please enter default value" />
        </el-form-item>
        <el-form-item label="Desc" prop="description">
          <el-input v-model="temp.description" type="textarea" :rows="3" placeholder="Please enter description" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">Confirm</el-button>
        <el-button @click="dialogFormVisible=false">Cancel</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { createDictionary, fetchDictionaryList, updateDictionary, deleteDictionary } from '@/api/dictionary'
import Pagination from '@/components/Pagination'
import BackToTop from '@/components/BackToTop'
import waves from '@/directive/waves/waves'

const supportTypeOptions = [
  { key: 'Text', display_name: 'Text' },
  { key: 'Integer', display_name: 'Integer' },
  { key: 'Decimal', display_name: 'Decimal' },
  { key: 'Date', display_name: 'Date' }
]

const supportTypeKeyValue = supportTypeOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

const supportCategoryOptions = [
  { key: 'AM_Account_Info', display_name: 'AM Account Info' },
  { key: 'IM_Account_Info', display_name: 'IM Account Info' },
  { key: 'FG_Account_Info', display_name: 'FG Account Info' },
  { key: 'FG_System', display_name: 'FG System' },
  { key: 'FT_Account_Info', display_name: 'FT Account Info' },
  { key: 'IP_Account_Info', display_name: 'IP Account Info' },
  { key: 'IT_Account_Info', display_name: 'IT Account Info' },
  { key: 'MD_Account_Info', display_name: 'MD Account Info' },
  { key: 'MF_Account_Info', display_name: 'MF Account Info' },
  { key: 'MX_Account_Info', display_name: 'MX Account Info' },
  { key: 'RM_Demographic_C_Level', display_name: 'RM Demographic C Level' },
  { key: 'RM_Demographic_R_Level', display_name: 'RM Demographic R Level' }
]

const supportCategoryKeyValue = supportCategoryOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

const supportSourceOptions = [
  { key: 'AM', display_name: 'ALS' },
  { key: 'IM', display_name: 'Impacts' },
  { key: 'AV', display_name: 'Advice' },
  { key: 'MF', display_name: 'Mutual Fund' },
  { key: 'FG', display_name: 'FG' },
  { key: 'FT', display_name: 'Fund Transfer' },
  { key: 'IP', display_name: 'IP' },
  { key: 'IT', display_name: 'IT' },
  { key: 'MD', display_name: 'MD' },
  { key: 'MX', display_name: 'MX' },
  { key: 'RM', display_name: 'Reln Mgmt' }
]

const supportSourceKeyValue = supportSourceOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

export default {
  name: 'DataDictionaryManagement',
  components: { Pagination, BackToTop },
  directives: { waves },
  filters: {
    typeFilter(type) {
      return supportTypeKeyValue[type]
    },
    categoryFilter(category) {
      return supportCategoryKeyValue[category]
    },
    sourceFilter(source) {
      return supportSourceKeyValue[source]
    }
  },
  myBackToTopStyle: {
    right: '50px',
    bottom: '50px',
    width: '40px',
    height: '40px',
    'border-radius': '4px',
    'line-height': '45px', // 请保持与高度一致以垂直居中 Please keep consistent with height to center vertically
    background: '#e7eaf1'// 按钮的背景颜色 The background color of the button
  },
  data() {
    return {
      listLoading: true,
      listQuery: {
        name: undefined,
        page: 1,
        limit: 20,
        type: 'All',
        category: 'All',
        source: 'All',
        sort: '+id'
      },
      list: null,
      total: 0,
      sortOptions: [{ label: 'ID Ascending', key: '+id' }, { label: 'ID Descending', key: '-id' }],
      supportTypeOptions: supportTypeOptions,
      supportCategoryOptions: supportCategoryOptions,
      supportSourceOptions: supportSourceOptions,
      temp: {
        id: undefined,
        name: undefined,
        type: undefined,
        category: undefined,
        source: undefined,
        format: undefined,
        defaultValue: '',
        description: ''
      },
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      rules: {
        name: [{ required: true, message: 'name is required', trigger: 'blur' }],
        type: [{ required: true, message: 'type is required', trigger: 'change' }],
        category: [{ required: true, message: 'category is required', trigger: 'blur' }],
        source: [{ required: true, message: 'source is required', trigger: 'blur' }],
        format: [{ required: true, message: 'format is required', trigger: 'blur' }],
        description: [{ required: true, message: 'description is required', trigger: 'blur' }]
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
      this.listLoading = true
      fetchDictionaryList(this.listQuery).then(resp => {
        this.list = resp.data.items
        this.total = resp.data.total

        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 1000)
      })
    },
    getSortClass: function(key) {
      const sort = this.listQuery.sort
      return sort === `+${key}` ? 'ascending' : 'descending'
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    sortByID(order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    sortChange(data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        name: undefined,
        type: undefined,
        category: undefined,
        source: undefined,
        format: undefined,
        defaultValue: '',
        description: ''
      }
    },
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          this.temp.id = parseInt(Math.random() * 100) + 1024 // mock an id
          createDictionary(this.temp).then(resp => {
            this.temp.id = resp.data
            this.list.unshift(this.temp)
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Created Successfully',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row) // copy obj
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          updateDictionary(tempData).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Update Successfully',
              type: 'success',
              duration: 5000
            })
          })
        }
      })
    },
    handleDelete(row, index) {
      deleteDictionary(row.id).then(resp => {
        this.$notify({
          title: 'Success',
          message: 'Deleted Successfully',
          type: 'success',
          duration: 5000
        })
        this.list.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped>

</style>
