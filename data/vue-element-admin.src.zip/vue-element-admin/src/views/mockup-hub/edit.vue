<template>
  <div class="createPost-container">
    <el-form ref="postForm" :model="postForm" :rules="rules" class="form-container">
      <div class="createPost-main-container">
        <el-row>
          <Warning />
          <h2 style="margin-bottom: 40px;">{{ postForm.name }}</h2>
          <el-col :span="24">
            <div class="postInfo-container">
              <el-row>
                <el-col :span="8">
                  <el-form-item label="Reviewer:" class="">
                    <el-select v-model="postForm.reviewer" :remote-method="getRemoteUserList" filterable default-first-option remote placeholder="Search user">
                      <el-option v-for="(item,index) in userListOptions" :key="item+index" :label="item" :value="item" />
                    </el-select>
                  </el-form-item>
                </el-col>

                <el-col :span="10">
                  <el-form-item label-width="120px" label="Release Date:" class="postInfo-container-item">
                    <el-date-picker v-model="postForm.releaseDate" type="datetime" format="yyyy-MM-dd HH:mm:ss" placeholder="Select date and time" />
                  </el-form-item>
                </el-col>

                <el-col :span="6">
                  <el-form-item label-width="90px" label="Priority:" class="postInfo-container-item">
                    <el-rate
                      v-model="postForm.priority"
                      :max="3"
                      :colors="['#99A9BF', '#F7BA2A', '#FF9900']"
                      :low-threshold="1"
                      :high-threshold="3"
                      style="display:inline-block"
                    />
                  </el-form-item>
                </el-col>
              </el-row>
            </div>
          </el-col>
        </el-row>

        <el-form-item style="margin-bottom: 40px;" label="Description:">
          <el-input v-model="postForm.description" :rows="1" type="textarea" class="article-textarea" autosize placeholder="Please enter the content" />
          <span v-show="descLength" class="word-counter">{{ descLength }} words</span>
        </el-form-item>

        <el-form-item prop="content" style="margin-bottom: 30px;">
          <Tinymce ref="editor" v-model="postForm.content" :height="400" />
        </el-form-item>

        <el-form-item align="center">
          <el-button type="primary" style="width: 140px" icon="el-icon-collection" @click="handleDataBinding">Bind</el-button>
          <el-button type="primary" style="width: 140px" icon="el-icon-finished" @click="submitForm">Save</el-button>
          <el-button type="primary" style="width: 140px" icon="el-icon-download" @click="downloadTemplate">Preview</el-button>
        </el-form-item>
      </div>
    </el-form>

    <el-dialog title="Data Binding" :visible.sync="dataBindingDialogVisible">
      <div>
        <el-table
          v-loading="listLoading"
          :data="dataBindingList"
          border
          fit
          highlight-current-row
          height="200"
          style="overflow-y: auto"
        >
          <el-table-column label="Placeholder" prop="placeholder" align="center" min-width="30">
            <template slot-scope="{row}">
              <span>{{ row.placeholder }}</span>
            </template>
          </el-table-column>
          <el-table-column label="Dictionary" prop="dictionary" align="center" min-width="40">
            <template slot-scope="{row}">
              <el-tooltip effect="dark" placement="right" :open-delay="500">
                <div slot="content" style="width: 380px">
                  <el-form>
                    <el-form-item label-width="120px" label="Description" class="postInfo-container-item">
                      <span>{{ row.dictionary.description }}</span>
                    </el-form-item>
                    <el-form-item label-width="120px" label="Category" class="postInfo-container-item">
                      <span>{{ row.dictionary.category }}</span>
                    </el-form-item>
                    <el-form-item label-width="120px" label="Source" class="postInfo-container-item">
                      <span>{{ row.dictionary.source }}</span>
                    </el-form-item>
                    <el-form-item label-width="120px" label="Type" class="postInfo-container-item">
                      <span>{{ row.dictionary.type }}</span>
                    </el-form-item>
                    <el-form-item label-width="120px" label="Default Value" class="postInfo-container-item">
                      <span>{{ row.dictionary.defaultValue }}</span>
                    </el-form-item>
                    <el-form-item label-width="120px" label="Format" class="postInfo-container-item">
                      <span>{{ row.dictionary.format }}</span>
                    </el-form-item>
                  </el-form>
                </div>
                <span>{{ row.dictionary.name }}</span>
              </el-tooltip>
            </template>
          </el-table-column>
          <el-table-column label="Binding Type" prop="bindingType" align="center" min-width="30">
            <template slot-scope="{row}">
              <span>{{ row.bindingType }}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div>
        <el-form ref="postBindingForm" :model="postBindingForm" :rules="rules" label-position="right" label-width="100px">
          <h2 style="margin: 15px;" align="left">Bind More Variable</h2>
          <el-form-item label="Placeholder" prop="placeholder">
            <el-input v-model="postBindingForm.placeholder" style="width: 40%;" placeholder="Please enter placeholder" />
          </el-form-item>
          <el-form-item label="Source" prop="source">
            <el-select v-model="postBindingForm.source" placeholder="Source" clearable class="filter-item" @change="handleChangeSource">
              <el-option v-for="item in sourceList" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
            </el-select>
          </el-form-item>
          <el-form-item label="Dictionary" prop="dictionary">
            <el-select v-model="postBindingForm.dictionaryId" class="filter-item" placeholder="Please select dictionary" @change="handleDictionaryChangeInUpdate">
              <el-option v-for="item in dictionaryList" :key="item.id" :label="item.name" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-input v-model="postBindingForm.templateId" type="hidden" hidden />
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="bindVariable()">Bind</el-button>
        <el-button @click="dataBindingDialogVisible=false">Cancel</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Tinymce from '@/components/Tinymce'
import { fetchTempalte, updateTemplateEditor } from '@/api/template'
import { fetchDataBindingByTemplateId, createDataBinding } from '@/api/data-binding'
import { fetchDictionaryList } from '@/api/dictionary'
import { searchUser } from '@/api/remote-search'
import Warning from './Warning'

const supportSourceOptions = [
  { key: 'AM', display_name: 'ALS' },
  { key: 'IM', display_name: 'Impacts' },
  { key: 'AV', display_name: 'Advice' },
  { key: 'MF', display_name: 'Mutual Fund' },
  { key: 'FG', display_name: 'FG' },
  { key: 'FT', display_name: 'Fund Transfer' },
  { key: 'IP', display_name: 'IP' },
  { key: 'IT', display_name: 'IT' },
  { key: 'MD', display_name: 'MD' },
  { key: 'MX', display_name: 'MX' },
  { key: 'RM', display_name: 'Reln Mgmt' }
]

const defaultForm = {
  id: undefined,
  status: 'draft',
  name: '',
  content: '',
  description: '',
  oppm: '',
  market: undefined,
  author: undefined,
  priority: 1
}

const dataBindingForm = {
  placeholder: '',
  bindingType: 'single',
  processClassName: '',
  source: 'All',
  dictionaryId: undefined,
  templateId: undefined
}

export default {
  name: 'TemplateDetail',
  components: { Tinymce, Warning },
  props: {
    isEdit: {
      type: Boolean,
      default: true
    }
  },
  data() {
    const validateRequire = (rule, value, callback) => {
      if (value === '') {
        this.$message({
          message: rule.field + ' required',
          type: 'error'
        })
        callback(new Error(rule.field + ' required'))
      } else {
        callback()
      }
    }
    return {
      postForm: Object.assign({}, defaultForm),
      loading: false,
      userListOptions: [],
      rules: {
        content: [{ validator: validateRequire }]
      },
      bindingRules: {
        placeholder: [{ validator: validateRequire }],
        dictionary: [{ validator: validateRequire }]
      },
      tempRoute: {},
      dataBindingDialogVisible: false,
      listLoading: false,
      dataBindingList: [],
      dictionaryList: [],
      sourceList: supportSourceOptions,
      postBindingForm: Object.assign({}, dataBindingForm)
    }
  },
  computed: {
    descLength() {
      return this.postForm.description.length
    },
    displayTime: {
      // set and get is useful when the data
      // returned by the back end api is different from the front end
      // back end return => "2013-06-25 06:59:25"
      // front end need timestamp => 1372114765000
      get() {
        return (+new Date(this.postForm.display_time))
      },
      set(val) {
        this.postForm.display_time = new Date(val)
      }
    }
  },
  created() {
    if (this.isEdit) {
      const id = this.$route.params && this.$route.params.id
      this.fetchData(id)
      this.getDataBindingList(id)
      this.getDictionaryList(this.postForm.market)
    }

    // Why need to make a copy of this.$route here?
    // Because if you enter this page and quickly switch tag, may be in the execution of the setTagsViewTitle function, this.$route is no longer pointing to the current page
    // https://github.com/PanJiaChen/vue-element-admin/issues/1221
    this.tempRoute = Object.assign({}, this.$route)
  },
  methods: {
    fetchData(id) {
      fetchTempalte(id).then(response => {
        // alert(JSON.stringify(response.data))
        this.postForm = response.data

        this.postBindingForm.templateId = this.postForm.id
        // set tagsview title
        this.setTagsViewTitle()

        // set page title
        this.setPageTitle()
      }).catch(err => {
        console.log(err)
      })
    },
    setTagsViewTitle() {
      const title = 'Mockup Visual Editor'
      const route = Object.assign({}, this.tempRoute, { title: `${title}` })
      this.$store.dispatch('tagsView/updateVisitedView', route)
    },
    setPageTitle() {
      const title = 'Edit Mockup'
      document.title = `${title} - ${this.postForm.id}`
    },
    submitForm() {
      console.log(this.postForm)
      this.$refs.postForm.validate(valid => {
        if (valid) {
          this.loading = true

          // alert('submit ' + this.postForm.content)
          // alert(window.tinymce.get('vue-tinymce-editor').getContent())

          const tempForm = Object.assign({}, this.postForm)
          tempForm.content = window.tinymce.get('vue-tinymce-editor').getContent()

          updateTemplateEditor(tempForm).then(() => {
            this.$notify({
              title: 'Succes',
              message: 'Saved Successfully!',
              type: 'success',
              duration: 2000
            })
            this.loading = false
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    downloadTemplate() {
      const aTag = document.createElement('a')
      aTag.href = process.env.VUE_APP_BASE_API + '/vue-element-admin/template/download/' + this.postForm.id
      aTag.click()
    },
    getRemoteUserList(query) {
      searchUser(query).then(response => {
        if (!response.data) return
        this.userListOptions = response.data // .map(v => v.name)
      })
    },
    getDataBindingList(templateId) {
      this.listLoading = true
      fetchDataBindingByTemplateId(templateId).then(resp => {
        this.dataBindingList = resp.data.items
        this.listLoading = false
      })
    },
    handleChangeSource(source) {
      this.getDictionaryList(source)
    },
    getDictionaryList(source) {
      if (source === 'All') {
        fetchDictionaryList(null).then(resp => {
          this.dictionaryList = resp.data.items
        })
      } else {
        const query = { source: source }
        fetchDictionaryList(query).then(resp => {
          this.dictionaryList = resp.data.items
        })
      }
    },
    handleDictionaryChangeInUpdate(dictionaryId) {
      this.dictionaryList.forEach((item) => {
        if (item.id === dictionaryId) {
          this.postBindingForm.dictionaryId = item.id
        }
      })
    },
    handleDataBinding() {
      this.dataBindingDialogVisible = true
    },
    bindVariable() {
      this.$refs['postBindingForm'].validate((valid) => {
        if (valid) {
          createDataBinding(this.postBindingForm).then(() => {
            this.getDataBindingList(this.postBindingForm.templateId)
            this.dataBindingDialogVisible = false
            this.$notify({
              title: 'Success',
              message: 'Bind Successfully',
              type: 'success',
              duration: 5000
            })
            this.$nextTick(() => {
              this.$refs['postBindingForm'].clearValidate()
            })
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import "~@/styles/mixin.scss";

.createPost-container {
  position: relative;

  .createPost-main-container {
    padding: 40px 45px 20px 50px;

    .postInfo-container {
      position: relative;
      @include clearfix;
      margin-bottom: 10px;

      .postInfo-container-item {
        float: left;
      }
    }
  }

  .word-counter {
    position: absolute;
    right: 10px;
    top: 0px;
  }
}

.article-textarea ::v-deep {
  textarea {
    padding-right: 40px;
    resize: none;
    border: none;
    border-radius: 0px;
    border-bottom: 1px solid #bfcbd9;
  }
}

</style>
