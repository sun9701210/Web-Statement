<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input v-model="listQuery.name" placeholder="Name Wildcard" style="width: 200px" class="filter-item" @keyup.enter.native="handleFilter" />
      <el-select v-model="listQuery.priority" placeholder="Priority" clearable style="margin-left: 10px;width: 100px;" class="filter-item">
        <el-option v-for="item in priorityOptions" :key="item" :label="item" :value="item" />
      </el-select>
      <el-select v-model="listQuery.market" placeholder="Market" clearable class="filter-item" style="margin-left: 10px;width: 170px;" @change="handleChangeMarket">
        <el-option v-for="item in supportMarketOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
      </el-select>
      <el-select v-model="listQuery.type" class="filter-item" style="margin-left: 10px;width: 210px;" placeholder="Please select" @change="onTypeChange">
        <el-option v-for="folder in folderList" :key="folder.id" :label="folder.displayName" :value="folder" />
      </el-select>
      <el-select v-model="listQuery.sort" style="margin-left: 10px;width: 150px;" class="filter-item" @change="handleFilter">
        <el-option v-for="item in sortOptions" :key="item.key" :label="item.label" :value="item.key" />
      </el-select>
      <el-button v-waves style="margin-left: 10px;" class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">Search</el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="handleCreate">Add</el-button>
      <el-button v-waves :loading="downloadLoading" class="filter-item" type="primary" icon="el-icon-download" @click="handleDownload">Export</el-button>
      <el-checkbox v-model="showReviewer" class="filter-item" style="margin-left: 15px;" @change="tableKey=tableKey+1">Reviewer</el-checkbox>
      <!--<el-button type="primary" icon="el-icon-folder" class="filter-item tree" style="margin-right: 0px; float: right" @click="handleChangeType">Choose Type</el-button>-->
    </div>
    <div>
      <el-header>Current Document Type - {{ listQuery.type }}</el-header>
    </div>
    <el-table
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%;"
      @sort-change="sortChange"
    >
      <el-table-column label="ID" prop="id" sortable="custom" align="center" width="80" :class-name="getSortClass('id')">
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Name" min-width="150px" align="left" header-align="center">
        <template slot-scope="{row}">
          <el-tag style="margin-right: 5px">{{ row.folder.name }}</el-tag>
          <span class="link-type" @click="handleUpdate(row)">{{ row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Market" min-width="90px" align="center">
        <template slot-scope="{row}">
          <span>{{ row.market }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Ref OPPM" width="150px" align="center">
        <template slot-scope="{row}">
          <span>{{ row.oppm }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Release Date" width="150px" align="center">
        <template slot-scope="{row}">
          <span>{{ row.releaseDate | parseTime('{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Doc Description" width="200px" align="center">
        <template slot-scope="{row}">
          <span>{{ row.folder.description }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Last Author" width="150px" align="center">
        <template slot-scope="{row}">
          <span>{{ row.lastUpdatedBy }}</span>
        </template>
      </el-table-column>
      <el-table-column v-if="showReviewer" label="Reviewer" width="100px" align="center">
        <template slot-scope="{row}">
          <span style="color: red;">{{ row.reviewer }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Priority" width="80px">
        <template slot-scope="{row}">
          <svg-icon v-for="n in row.priority" :key="n" icon-class="star" class="meta-item_icon" />
        </template>
      </el-table-column>
      <el-table-column label="Variables" align="center" width="95">
        <template slot-scope="{row}">
          <span v-if="row.variableCount" class="link-type" @click="handleFetchVariables(row.id)">{{ row.variableCount }}</span>
          <span v-else>0</span>
        </template>
      </el-table-column>
      <el-table-column label="Status" class-name="status-col" width="100px">
        <template slot-scope="{row}">
          <el-tag :type="row.status | statusFilter">{{ row.status }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Actions" header-align="center" align="left" width="350px" class-name="big-padding fixed-width">
        <template slot-scope="{row, $index}">
          <el-button v-if="row.status=='Deleted'" size="mini" @click="handleModifyStatus(row, 'Draft')">Draft</el-button>
          <el-button v-if="row.status=='Draft'" size="mini" type="success" plain @click="handleModifyStatus(row, 'Published')">Publish</el-button>
          <el-button v-if="row.status=='Published'" type="warning" size="mini" @click="handleModifyStatus(row, 'Progress')">Progress</el-button>
          <el-button v-if="row.status=='Progress'" size="mini" type="success" @click="handleModifyStatus(row, 'Released')">Release</el-button>
          <el-button type="primary" size="mini" @click="handleUpdate(row)">Edit</el-button>
          <el-button v-if="row.status=='Draft'" type="primary" size="mini">
            <router-link :to="'/mockup-hub/edit/'+row.id">Visual Edit</router-link>
          </el-button>

          <el-button v-if="row.status!='Deleted'" size="mini" type="danger" @click="handleDelete(row, $index)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="70px" style="width: 400px; margin-left: 50px;">
        <el-form-item label="Name" prop="name">
          <el-input v-model="temp.name" />
        </el-form-item>
        <el-form-item label="Market" prop="market">
          <el-select v-model="temp.market" class="filter-item" placeholder="Please select" @change="handleChangeMarket">
            <el-option v-for="item in supportMarketOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item label="Type" prop="folder">
          <el-select v-model="temp.folder.id" class="filter-item" placeholder="Please select type" @change="handleTypeChangeCreateUpdate">
            <el-option v-for="item in folderList" :key="item.id" :label="item.displayName" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="OPPM" prop="oppm">
          <el-input v-model="temp.oppm" />
        </el-form-item>
        <el-form-item label="Date" prop="releaseDate">
          <el-date-picker v-model="temp.releaseDate" type="datetime" placeholder="Please pick a date" />
        </el-form-item>
        <el-form-item label="Status">
          <el-tag :type="temp.status | statusFilter">{{ temp.status }}</el-tag>
        </el-form-item>
        <el-form-item label="Priority">
          <el-rate v-model="temp.priority" :colors="['#99A9BF','#F7BA2A','#FF9900']" :max="3" style="margin-top: 8px;" />
        </el-form-item>
        <el-form-item label="Desc" prop="description">
          <el-input v-model="temp.description" type="textarea" :rows="3" placeholder="Please enter description" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">Confirm</el-button>
        <el-button @click="dialogFormVisible=false">Cancel</el-button>
      </div>
    </el-dialog>

    <el-dialog :visible.sync="dialogMarketVisible" title="Variable Listing">
      <el-table :data="marketData" border fit highlight-current-row style="width: 100%">
        <el-table-column label="Variable" class-name="status-col" min-width="30">
          <template slot-scope="{row}">
            <span>{{ row.dictionary.name }}</span>
          </template>
        </el-table-column>
        <el-table-column label="Default Value" class-name="status-col" min-width="30">
          <template slot-scope="{row}">
            <span>{{ row.dictionary.defaultValue }}</span>
          </template>
        </el-table-column>
        <el-table-column label="Description" class-name="status-col" min-width="40">
          <template slot-scope="{row}">
            <span>{{ row.dictionary.description }}</span>
          </template>
        </el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogMarketVisible=false">Confirm</el-button>
      </span>
    </el-dialog>

    <el-dialog :visible.sync="dialogChangeTypeVisible" title="Choose Type">
      <div align="center">
        <el-select v-model="listQuery.type" class="filter-item" placeholder="Please select" @change="onTypeChange">
          <el-option v-for="folder in folderList" :key="folder.id" :label="folder.displayName" :value="folder" />
        </el-select>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="filterByType">Choose</el-button>
        <el-button @click="dialogChangeTypeVisible=false">Cancel</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { fetchTemplateList, createTemplate, updateTemplate, fetchTemplateFolderByMarket, deleteTemplate } from '@/api/template'
import Pagination from '@/components/Pagination'
import waves from '@/directive/waves/waves'
import { parseTime } from '@/utils'
import { validMockupName } from '@/utils/validate'
import store from '@/store'
import { fetchDataBindingByTemplateId } from '@/api/data-binding'

const supportMarketOptions = [
  { key: 'CN', display_name: 'China' },
  { key: 'HK', display_name: 'Hong Kong' },
  { key: 'TW', display_name: 'Taiwan' },
  { key: 'SG', display_name: 'Singapore' }
]

const supportMarketKeyValue = supportMarketOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

export default {
  name: 'MockupHubManagement',
  components: { Pagination },
  directives: { waves },
  filters: {
    statusFilter(status) {
      const statusMap = {
        Published: 'success',
        Draft: 'info',
        Progress: 'warning',
        Deleted: 'danger',
        Released: 'success'
      }
      return statusMap[status]
    },
    marketFilter(market) {
      return supportMarketKeyValue[market]
    }
  },
  data() {
    const validateMockupName = (rule, value, callback) => {
      if (!validMockupName(value)) {
        callback(new Error('Advice - please input 5 digits advice type name.'))
      } else {
        callback()
      }
    }
    return {
      tableKey: 0,
      list: null,
      folderList: null,
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10,
        priority: undefined,
        name: undefined,
        market: 'All',
        sort: '-id',
        type: 'All',
        typeId: null
      },
      priorityOptions: [1, 2, 3],
      supportMarketOptions: supportMarketOptions,
      sortOptions: [{ label: 'ID Descending', key: '-id' }, { label: 'ID Ascending', key: '+id' }],
      statusOptions: ['Published', 'Draft', 'Deleted', 'Progress', 'Released'],
      showReviewer: false,
      temp: {
        id: undefined,
        folder: { id: 0 },
        name: undefined,
        content: undefined,
        description: undefined,
        oppm: undefined,
        market: undefined,
        releaseDate: undefined,
        status: 'Draft',
        priority: 1,
        lastUpdatedBy: undefined
      },
      dialogFormVisible: false,
      dialogVisualEditorVisible: false,
      dialogChangeTypeVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      dialogMarketVisible: false,
      marketData: [],
      rules: {
        market: [{ required: true, message: 'market is required', trigger: 'change' }],
        releaseDate: [{ type: 'date', required: true, message: 'release date is required', trigger: 'change' }],
        name: [
          // { required: true, message: 'name is required', trigger: 'blur' },
          { required: true, trigger: 'blur', validator: validateMockupName }
        ],
        oppm: [{ required: true, message: 'oppm is required', trigger: 'change' }],
        description: [{ required: true, message: 'description is required', trigger: 'blur' }],
        folder: [{ required: true, message: 'type is required', trigger: 'blur' }]
      },
      downloadLoading: false
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
      this.listLoading = true
      // alert(JSON.stringify(this.listQuery))
      fetchTemplateList(this.listQuery).then(resp => {
        this.list = resp.data.items
        this.total = resp.data.total

        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 1000)
      })
    },
    handleModifyStatus(row, status) {
      // here should call api to change status
      this.$message({
        message: 'Operation Success',
        type: 'success'
      })
      row.status = status
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    sortByID(order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    sortChange(data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        folder: { id: 0 },
        name: undefined,
        content: undefined,
        description: undefined,
        oppm: undefined,
        market: undefined,
        releaseDate: undefined,
        status: 'Draft',
        priority: 1
      }
    },
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          this.temp.id = parseInt(Math.random() * 100) + 1024 // mock an id
          this.temp.author = store.getters.name
          this.temp.lastUpdatedBy = store.getters.name
          createTemplate(this.temp).then(resp => {
            // this.temp.id = resp.data
            // this.list.unshift(this.temp)
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Created Successfully',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleChangeMarket(market) {
      this.temp.market = market
      fetchTemplateFolderByMarket(market).then(resp => {
        this.folderList = resp.data.items
        if (this.folderList.length === 0) {
          this.temp.folder = undefined
        } else {
          this.temp.folder = this.folderList[0]
        }
      })
    },
    handleTypeChangeCreateUpdate(typeId) {
      this.folderList.forEach((item) => {
        if (item.id === typeId) {
          this.temp.folder = item
        }
      })
    },
    handleChangeType() {
      this.dialogChangeTypeVisible = true
      const market = this.listQuery.market
      fetchTemplateFolderByMarket(market).then(resp => {
        this.folderList = resp.data.items
      })
    },
    onTypeChange(type) {
      // alert(JSON.stringify(type))
      this.listQuery.type = type.displayName
      this.listQuery.typeId = type.id
      this.getList()
    },
    filterByType() {
      this.dialogChangeTypeVisible = false
      this.getList()
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row) // copy obj
      this.temp.releaseDate = new Date(this.temp.releaseDate)
      fetchTemplateFolderByMarket(this.temp.market).then(resp => {
        this.folderList = resp.data.items
      })

      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          tempData.releaseDate = +new Date(tempData.releaseDate)
          updateTemplate(tempData).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Update Successfully',
              type: 'success',
              duration: 5000
            })
          })
        }
      })
    },
    handleDelete(row, index) {
      // here should call api to delete template
      deleteTemplate(row.id).then(resp => {
        this.$notify({
          title: 'Success',
          message: 'Deleted Successfully',
          type: 'success',
          duration: 5000
        })
        this.list.splice(index, 1)
      })
    },
    handleFetchVariables(id) {
      fetchDataBindingByTemplateId(id).then(resp => {
        this.marketData = resp.data.items
        this.dialogMarketVisible = true
      })
    },
    formatJson(filterVal) {
      return this.list.map(v => filterVal.map(j => {
        if (j === 'releaseDate') {
          return parseTime(v[j])
        }
        if (j === 'folder') {
          return v[j].name
        }
        return v[j]
      }))
    },
    formatExcelFileName() {
      let fName = 'template-list'
      // if (this.listQuery.market) {
      //   fName += '-'+this.listQuery.market
      // }
      if (this.listQuery.type) {
        fName += '-' + this.listQuery.type.replace(' ', '_')
      }
      return fName
    },
    handleDownload() {
      this.downloadLoading = true
      import('@/vendor/Export2Excel').then(excel => {
        const tHeader = ['Release Date', 'OPPM', 'Doc Type', 'Name', 'Market', 'Priority', 'Status', 'Description']
        const filterVal = ['releaseDate', 'oppm', 'folder', 'name', 'market', 'priority', 'status', 'description']
        const data = this.formatJson(filterVal)
        const fileName = this.formatExcelFileName()
        excel.export_json_to_excel({
          header: tHeader,
          data,
          filename: fileName
        })
        this.downloadLoading = false
      })
    },
    getSortClass: function(key) {
      const sort = this.listQuery.sort
      return sort === `+${key}` ? 'ascending' : 'descending'
    }
  }
}
</script>
