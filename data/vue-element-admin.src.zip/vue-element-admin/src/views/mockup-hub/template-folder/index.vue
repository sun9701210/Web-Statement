<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input v-model="listQuery.name" placeholder="Name" style="width: 200px" class="filter-item" @keyup.enter.native="handleFilter" />
      <el-select v-model="listQuery.market" placeholder="Market" clearable style="margin-left: 10px;width: 100px;" class="filter-item">
        <el-option v-for="item in supportMarketOptions" :key="item" :label="item.display_name+'('+item.key+')'" :value="item.key" />
      </el-select>
      <el-select v-model="listQuery.category" placeholder="Category" clearable class="filter-item" style="margin-left: 10px;width: 130px;">
        <el-option v-for="item in supportCategoryOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
      </el-select>
      <el-select v-model="listQuery.source" placeholder="Source" clearable class="filter-item" style="margin-left: 10px;width: 130px;">
        <el-option v-for="item in supportSourceOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
      </el-select>
      <el-select v-model="listQuery.sort" style="margin-left: 10px;width: 140px;" class="filter-item" @change="handleFilter">
        <el-option v-for="item in sortOptions" :key="item.key" :label="item.label" :value="item.key" />
      </el-select>
      <el-button v-waves style="margin-left: 10px;" class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">Search</el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="handleCreate">Add</el-button>
      <el-button v-waves :loading="downloadLoading" class="filter-item" type="primary" icon="el-icon-download" @click="handleDownload">Export</el-button>
    </div>
    <div>
      <el-header>Current Market - {{ listQuery.market }}</el-header>
    </div>

    <el-table
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%;"
      @sort-change="sortChange"
    >
      <el-table-column label="ID" prop="id" sortable="custom" align="center" min-width="10" :class-name="getSortClass('id')">
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Name" prop="name" align="left" header-align="center" min-width="20">
        <template slot-scope="{row}">
          <el-tag style="margin-right: 5px">{{ row.market | marketFilter }}</el-tag>
          <span class="link-type" @click="handleUpdate(row)">{{ row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Market" prop="market" align="center" min-width="10">
        <template slot-scope="{row}">
          <span>{{ row.market }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Category" prop="category" align="center" min-width="10">
        <template slot-scope="{row}">
          <span>{{ row.category }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Source" prop="source" align="center" min-width="10">
        <template slot-scope="{row}">
          <span>{{ row.source }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Description" prop="description" align="center" min-width="10">
        <template slot-scope="{row}">
          <span>{{ row.description }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Actions" header-align="center" align="center" min-width="30" class-name="big-padding fixed-width">
        <template slot-scope="{row, $index}">
          <el-button type="primary" size="mini" @click="handleUpdate(row)">Edit</el-button>
          <el-button v-if="row.status!='Deleted'" size="mini" type="danger" @click="handleDelete(row, $index)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="temp" label-position="right" label-width="100px" style="width: 400px; margin-left: 50px;">
        <el-form-item label="Type Name" prop="name">
          <el-input v-model="temp.name" />
        </el-form-item>
        <el-form-item label="Market" prop="market">
          <el-select v-model="temp.market" class="filter-item" placeholder="Please select">
            <el-option v-for="item in supportMarketOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item label="Category" prop="category">
          <el-select v-model="temp.category" class="filter-item" placeholder="Please select">
            <el-option v-for="item in supportCategoryOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item label="Source" prop="source">
          <el-select v-model="temp.source" class="filter-item" placeholder="Please select">
            <el-option v-for="item in supportSourceOptions" :key="item.key" :label="item.display_name+'('+item.key+')'" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item label="Desc" prop="description">
          <el-input v-model="temp.description" type="textarea" :rows="3" placeholder="Please enter description" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">Confirm</el-button>
        <el-button @click="dialogFormVisible=false">Cancel</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  createTemplateFolder,
  deleteTemplateFolder,
  fetchTemplateFolderList,
  updateTemplateFolder
} from '@/api/template'
import Pagination from '@/components/Pagination'
import waves from '@/directive/waves/waves'

const supportMarketOptions = [
  { key: 'CN', display_name: 'China' },
  { key: 'HK', display_name: 'Hong Kong' },
  { key: 'TW', display_name: 'Taiwan' },
  { key: 'SG', display_name: 'Singapore' }
]

const supportMarketKeyValue = supportMarketOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

const supportCategoryOptions = [
  { key: 'AV', display_name: 'Advice' },
  { key: 'CS', display_name: 'Combined Statement' }
]

const supportCategoryKeyValue = supportCategoryOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

const supportSourceOptions = [
  { key: 'AM', display_name: 'ALS' },
  { key: 'IM', display_name: 'Impacts' }
]

const supportSourceKeyValue = supportSourceOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

export default {
  name: 'DocumentTypeManagement',
  components: { Pagination },
  directives: { waves },
  filters: {
    marketFilter(market) {
      return supportMarketKeyValue[market]
    },
    categoryFilter(category) {
      return supportCategoryKeyValue[category]
    },
    sourceFilter(source) {
      return supportSourceKeyValue[source]
    }
  },
  data() {
    return {
      listLoading: true,
      listQuery: {
        name: undefined,
        page: 1,
        limit: 20,
        market: 'All',
        category: 'All',
        source: 'All',
        sort: '+id'
      },
      list: null,
      total: 0,
      sortOptions: [{ label: 'ID Ascending', key: '+id' }, { label: 'ID Descending', key: '-id' }],
      supportMarketOptions: supportMarketOptions,
      supportCategoryOptions: supportCategoryOptions,
      supportSourceOptions: supportSourceOptions,
      temp: {
        id: undefined,
        name: undefined,
        market: undefined,
        category: undefined,
        source: undefined,
        description: undefined
      },
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      rules: {
        name: [{ required: true, message: 'name is required', trigger: 'blur' }],
        market: [{ required: true, message: 'market is required', trigger: 'change' }],
        category: [{ required: true, message: 'category is required', trigger: 'blur' }],
        source: [{ required: true, message: 'source is required', trigger: 'blur' }],
        description: [{ required: true, message: 'description is required', trigger: 'blur' }]
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
      this.listLoading = true
      fetchTemplateFolderList(this.listQuery).then(resp => {
        this.list = resp.data.items
        this.total = resp.data.total

        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 1000)
      })
    },
    getSortClass: function(key) {
      const sort = this.listQuery.sort
      return sort === `+${key}` ? 'ascending' : 'descending'
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    sortByID(order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    sortChange(data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        name: undefined,
        type: undefined,
        category: undefined,
        source: undefined,
        description: undefined
      }
    },
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          this.temp.id = parseInt(Math.random() * 100) + 1024 // mock an id
          createTemplateFolder(this.temp).then(resp => {
            this.temp.id = resp.data.id
            this.list.unshift(this.temp)
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Created Successfully',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row) // copy obj
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          updateTemplateFolder(tempData).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: 'Success',
              message: 'Update Successfully',
              type: 'success',
              duration: 5000
            })
          })
        }
      })
    },
    handleDelete(row, index) {
      deleteTemplateFolder(row.id).then(resp => {
        this.$notify({
          title: 'Success',
          message: 'Deleted Successfully',
          type: 'success',
          duration: 5000
        })
        this.list.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped>

</style>
