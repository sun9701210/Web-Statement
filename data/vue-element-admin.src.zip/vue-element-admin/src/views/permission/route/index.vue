<template>
  <div class="app-container">
    <el-button type="primary" @click="handleAddRoute">New Route</el-button>

    <el-table v-loading="listLoading" :data="routes" style="width: 100%;margin-top:30px;" border>
      <el-table-column align="center" label="ID" width="220">
        <template slot-scope="scope">
          {{ scope.row.id }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Name" width="220">
        <template slot-scope="scope">
          {{ scope.row.name }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Title" width="220">
        <template slot-scope="scope">
          {{ scope.row.meta.title }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Path">
        <template slot-scope="scope">
          {{ scope.row.path }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Redirect">
        <template slot-scope="scope">
          {{ scope.row.redirect }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Always Show">
        <template slot-scope="scope">
          {{ scope.row.alwaysShow }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Hidden">
        <template slot-scope="scope">
          {{ scope.row.hidden }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Operations" min-width="150">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="handleEdit(scope)">Edit</el-button>
          <el-button type="danger" size="small" @click="handleDelete(scope)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog :visible.sync="dialogVisible" :title="dialogType==='edit'?'Edit Route':'New Route'">
      <el-form :model="route" label-width="150px" label-position="right">
        <el-form-item label="Parent">
          <el-select v-model="route.parent.id" placeholder="Please choose" @change="handleParentChange">
            <el-option v-for="item in parentRoutes" :key="item.id" :value="item.id" :label="item.meta.title" />
          </el-select>
        </el-form-item>
        <el-form-item label="Name">
          <el-input v-model="route.name" placeholder="Route Name" />
        </el-form-item>
        <el-form-item label="Path">
          <el-input v-model="route.path" placeholder="Route Path" />
        </el-form-item>
        <el-form-item label="Component">
          <el-input v-model="route.component" placeholder="Route Component" />
        </el-form-item>
        <el-form-item label="Redirect">
          <el-input v-model="route.redirect" placeholder="Route Redirect" />
        </el-form-item>
        <el-form-item label="Always Show">
          <el-radio-group v-model="route.alwayShow">
            <el-radio :label="true">Always Show</el-radio>
            <el-radio :label="false">Always Hide</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="Hidden">
          <el-radio-group v-model="route.hidden">
            <el-radio :label="false">Show</el-radio>
            <el-radio :label="true">Hide</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="Title">
          <el-input v-model="route.meta.title" placeholder="Menu Title" />
        </el-form-item>
        <el-form-item label="Icon">
          <el-input v-model="route.meta.icon" placeholder="Menu Icon" />
          <el-radio-group v-model="route.meta.icon" size="large">
            <el-radio v-for="item in icons" :key="item.key" :label="item.key"><i :class="item.key" /> {{ item.value }}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="Active Menu">
          <el-input v-model="route.meta.activeMenu" placeholder="Route Active Menu" />
        </el-form-item>
        <el-form-item label="No Cache">
          <el-radio-group v-model="route.meta.noCache">
            <el-radio :label="true">Yes</el-radio>
            <el-radio :label="false">No</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="Show Breadcrumb">
          <el-radio-group v-model="route.meta.breadcrumb">
            <el-radio :label="true">Show</el-radio>
            <el-radio :label="false">Hide</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="Affix">
          <el-radio-group v-model="route.meta.affix">
            <el-radio :label="true">Yes</el-radio>
            <el-radio :label="false">No</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div style="text-align:right;">
        <el-button type="danger" @click="dialogVisible=false">Cancel</el-button>
        <el-button type="primary" @click="confirmRoute">Confirm</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import path from 'path'
import { deepClone } from '@/utils'
import { addRoute, getRoutes, deleteRoute, updateRoute } from '@/api/route'

const iconList = [
  { key: 'el-icon-delete-solid', value: 'delete-solid' },
  { key: 'el-icon-delete', value: 'delete' },
  { key: 'el-icon-s-tools', value: 's-tools' }
]

const nullRoute = {
  id: 0,
  meta: {
    roles: [],
    title: 'No Parent',
    icon: '',
    activeMenu: '',
    noCache: false,
    breadcrumb: false,
    affix: false
  },
  parent: undefined
}

const nullMeta = {
  roles: [],
  title: '',
  icon: '',
  activeMenu: '',
  noCache: false,
  breadcrumb: false,
  affix: false
}

const defaultRoute = {
  id: 0,
  path: '',
  component: '',
  redirect: '',
  alwayShow: false,
  hidden: true,
  meta: nullMeta,
  parent: nullRoute,
  children: []
}

export default {
  data() {
    return {
      route: Object.assign({}, defaultRoute),
      routes: [],
      listLoading: true,
      rolesList: [],
      icons: iconList,
      dialogVisible: false,
      dialogType: 'new',
      checkStrictly: false,
      defaultProps: {
        children: 'children',
        label: 'title'
      }
    }
  },
  computed: {
    routesData() {
      return this.routes
    },
    parentRoutes() {
      const parent = []
      parent.push(nullRoute)
      for (const r of this.routes) {
        if (r.id === this.route.id) { continue }
        parent.push(r)
      }

      return parent
    }
  },
  created() {
    // Mock: get all routes and roles list from server
    this.getRoutes()
  },
  methods: {
    getRoutes() {
      this.listLoading = true
      getRoutes().then(resp => {
        this.routes = resp.data.items

        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 1000)
      })
    },
    findParentRoutes(routeId) {
      for (const route of this.routes) {
        if (route.id === routeId) return route
      }
      return null
    },
    // Reshape the routes structure so that it looks the same as the sidebar
    generateRoutes(routes, basePath = '/') {
      const res = []

      for (let route of routes) {
        // skip some route
        if (route.hidden) { continue }

        const onlyOneShowingChild = this.onlyOneShowingChild(route.children, route)

        if (route.children && onlyOneShowingChild && !route.alwaysShow) {
          route = onlyOneShowingChild
        }

        const data = {
          path: path.resolve(basePath, route.path),
          title: route.meta && route.meta.title

        }

        // recursive child routes
        if (route.children) {
          data.children = this.generateRoutes(route.children, data.path)
        }
        res.push(data)
      }
      return res
    },
    generateArr(routes) {
      let data = []
      routes.forEach(route => {
        data.push(route)
        if (route.children) {
          const temp = this.generateArr(route.children)
          if (temp.length > 0) {
            data = [...data, ...temp]
          }
        }
      })
      return data
    },
    handleParentChange(parentId) {
      // alert(parentId)
      // if (parentId === 0) {
      //   this.route.parent = null
      // }
    },
    handleAddRoute() {
      this.route = Object.assign({}, defaultRoute)
      this.route.meta = Object.assign({}, nullMeta)
      // if (this.$refs.tree) {
      //   this.$refs.tree.setCheckedNodes([])
      // }
      this.dialogType = 'new'
      this.dialogVisible = true
    },
    handleEdit(scope) {
      this.dialogType = 'edit'
      this.dialogVisible = true
      this.checkStrictly = true
      this.route = deepClone(scope.row)
      if (this.route.parent === null) {
        this.route.parent = {}
      }
      this.$nextTick(() => {
        // const routes = this.generateRoutes(this.route.routes)
        // this.$refs.tree.setCheckedNodes(this.generateArr(routes))
        // set checked state of a node not affects its father and child nodes
        this.checkStrictly = false
      })
    },
    handleDelete({ $index, row }) {
      this.$confirm('Confirm to remove the route?', 'Warning', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning'
      })
        .then(async() => {
          deleteRoute(row.id).then(resp => {
            if (resp.code === 20000) {
              this.routes.splice($index, 1)
              this.$message({
                type: 'success',
                message: 'Delete succed!'
              })
            } else {
              this.$message({
                type: 'error',
                message: resp.message
              })
            }
          })
        })
        .catch(err => { console.error(err) })
    },
    generateTree(routes, basePath = '/', checkedKeys) {
      const res = []

      for (const route of routes) {
        const routePath = path.resolve(basePath, route.path)

        // recursive child routes
        if (route.children) {
          route.children = this.generateTree(route.children, routePath, checkedKeys)
        }

        if (checkedKeys.includes(routePath) || (route.children && route.children.length >= 1)) {
          res.push(route)
        }
      }
      return res
    },
    async confirmRoute() {
      const isEdit = this.dialogType === 'edit'

      // const checkedKeys = this.$refs.tree.getCheckedKeys()
      // this.route.routes = this.generateTree(deepClone(this.serviceRoutes), '/', checkedKeys)

      const temp = Object.assign({}, this.route)
      if (this.route.parent === 0) {
        temp.parent = null
      } else {
        temp.parent = this.findParentRoutes(this.route.parent.id)
      }
      if (isEdit) {
        updateRoute(temp).then(resp => {
          this.getRoutes()
        })
        // for (let index = 0; index < this.routes.length; index++) {
        //   if (this.routes[index].key === this.route.key) {
        //     this.route.key = this.route.name.toLowerCase()
        //     this.routes.splice(index, 1, Object.assign({}, this.route))
        //     break
        //   }
        // }
        // this.getRoutes()
      } else {
        const { data } = await addRoute(temp)
        this.route.key = data.key
        this.route.id = data.id
        this.routes.push(this.route)
        // this.getRoutes()
      }

      const { path, meta, name } = this.route
      this.dialogVisible = false
      this.$notify({
        title: 'Success',
        dangerouslyUseHTMLString: true,
        message: `
            <div>Route Title: ${meta.title}</div>
            <div>Route Name: ${name}</div>
            <div>Path: ${path}</div>
          `,
        type: 'success'
      })
    },
    // reference: src/view/layout/components/Sidebar/SidebarItem.vue
    onlyOneShowingChild(children = [], parent) {
      let onlyOneChild = null
      const showingChildren = children.filter(item => !item.hidden)

      // When there is only one child route, the child route is displayed by default
      if (showingChildren.length === 1) {
        onlyOneChild = showingChildren[0]
        onlyOneChild.path = path.resolve(parent.path, onlyOneChild.path)
        return onlyOneChild
      }

      // Show parent if there are no child route to display
      if (showingChildren.length === 0) {
        onlyOneChild = { ... parent, path: '', noShowingChildren: true }
        return onlyOneChild
      }

      return false
    }
  }
}
</script>

<style lang="scss" scoped>
.app-container {
  .roles-table {
    margin-top: 30px;
  }
  .permission-tree {
    margin-bottom: 30px;
  }
}
</style>
