<template>
  <div class="app-container">
    <el-button type="primary" @click="handleAddUser">New User</el-button>

    <el-table :data="usersList" style="width: 100%;margin-top:30px;" border>
      <el-table-column align="center" label="User Name" width="220">
        <template slot-scope="scope">
          {{ scope.row.username }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="LPAR" width="220">
        <template slot-scope="scope">
          {{ scope.row.lpar }}
        </template>
      </el-table-column>
      <el-table-column align="header-center" label="Role List">
        <template slot-scope="scope">
          {{ scope.row.roleList }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Operations">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="handleEdit(scope)">Edit</el-button>
          <el-button type="danger" size="small" @click="handleDelete(scope)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog :visible.sync="dialogVisible" :title="dialogType==='edit'?'Edit User':'New User'">
      <el-form :model="user" label-width="120px" label-position="left">
        <el-form-item label="User Name">
          <el-input v-model="user.username" placeholder="User Name" :readonly="dialogType==='edit'" />
        </el-form-item>
        <el-form-item label="LPAR">
          <el-input v-model="user.lpar" placeholder="LPAR" />
        </el-form-item>
        <el-form-item label="Roles">
          <el-tree
            ref="tree"
            :check-strictly="checkStrictly"
            :data="rolesData"
            :props="defaultProps"
            show-checkbox
            node-key="id"
            class="permission-tree"
          />
        </el-form-item>
      </el-form>
      <div style="text-align:right;">
        <el-button type="danger" @click="dialogVisible=false">Cancel</el-button>
        <el-button type="primary" @click="confirmUser">Confirm</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import path from 'path'
import { deepClone } from '@/utils'
import { getUsers, addUser, updateUserRole, deleteUser } from '@/api/user'
import { getRoles } from '@/api/role'
const defaultUser = {
  username: '',
  lpar: '',
  roleList: '',
  roles: []
}

export default {
  data() {
    return {
      user: Object.assign({}, defaultUser),
      usersList: [],
      rolesList: [],
      dialogVisible: false,
      dialogType: 'new',
      checkStrictly: false,
      defaultProps: {
        // children: 'children',
        label: 'name',
        key: 'id'
      }
    }
  },
  computed: {
    rolesData() {
      return this.rolesList
    }
  },
  created() {
    // Mock: get all routes and roles list from server
    // this.getRoutes()
    this.getUsers()
    this.getRoles()
  },
  methods: {
    async getUsers() {
      const resp = await getUsers()
      this.usersList = resp.data.items
    },
    // async getRoutes() {
    //   const res = await getRouteTree()
    //   this.serviceRoutes = res.data.items
    //   this.routes = this.generateRoutes(res.data.items)
    // },
    async getRoles() {
      const res = await getRoles()
      this.rolesList = res.data.items
    },

    // Reshape the routes structure so that it looks the same as the sidebar
    generateRoutes(routes, basePath = '/') {
      const res = []

      for (const route of routes) {
        // skip some route
        // if (route.hidden) { continue }

        // const onlyOneShowingChild = this.onlyOneShowingChild(route.children, route)
        //
        // if (route.children && onlyOneShowingChild && !route.alwaysShow) {
        //   route = onlyOneShowingChild
        // }

        const data = {
          path: path.resolve(basePath, route.path),
          title: route.meta && route.meta.title

        }

        // alert(data.title + ': ' + data.path)

        // recursive child routes
        if (route.children) {
          data.children = this.generateRoutes(route.children, data.path)
        }
        res.push(data)
      }
      return res
    },
    generateArr(routes) {
      let data = []
      routes.forEach(route => {
        data.push(route)
        if (route.children) {
          const temp = this.generateArr(route.children)
          if (temp.length > 0) {
            data = [...data, ...temp]
          }
        }
      })
      return data
    },
    handleAddUser() {
      this.user = Object.assign({}, defaultUser)
      if (this.$refs.tree) {
        this.$refs.tree.setCheckedNodes([])
      }
      this.dialogType = 'new'
      this.dialogVisible = true
    },
    handleEdit(scope) {
      this.dialogType = 'edit'
      this.dialogVisible = true
      this.checkStrictly = true
      this.user = deepClone(scope.row)
      this.$nextTick(() => {
        // const roles = this.generateRoutes(this.role.routes)
        this.$refs.tree.setCheckedNodes(this.user.roles)
        // set checked state of a node not affects its father and child nodes
        this.checkStrictly = false
      })
    },
    handleDelete({ $index, row }) {
      this.$confirm('Confirm to remove the user?', 'Warning', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning'
      })
        .then(async() => {
          await deleteUser(row.id)
          this.usersList.splice($index, 1)
          this.$message({
            type: 'success',
            message: 'Delete successfully!'
          })
        })
        .catch(err => { console.error(err) })
    },
    generateRoleArray(roles, checkedKeys) {
      const res = []

      for (const role of roles) {
        if (checkedKeys.includes(role.id)) {
          res.push(role)
        }
      }

      return res
    },
    generateTree(routes, basePath = '/', checkedKeys) {
      const res = []

      for (const route of routes) {
        const routePath = path.resolve(basePath, route.path)

        // recursive child routes
        if (route.children) {
          route.children = this.generateTree(route.children, routePath, checkedKeys)
        }

        if (checkedKeys.includes(routePath) || (route.children && route.children.length >= 1)) {
          res.push(route)
        }
      }
      return res
    },
    async confirmUser() {
      const isEdit = this.dialogType === 'edit'

      const checkedKeys = this.$refs.tree.getCheckedKeys()
      // alert(JSON.stringify(checkedKeys))
      // for (const key of checkedKeys) {
      //   alert(key)
      // }
      // const checkedNodes = this.$refs.tree.getCheckedNodes()
      // alert(JSON.stringify(checkedNodes))
      // for (const node of checkedNodes) {
      //   alert(node.id)
      // }
      // this.role.routes = this.generateTree(deepClone(this.serviceRoutes), '/', checkedKeys)
      this.user.roles = this.generateRoleArray(deepClone(this.rolesList), checkedKeys)

      if (isEdit) {
        await updateUserRole(this.user)
        // for (let index = 0; index < this.rolesList.length; index++) {
        //   if (this.rolesList[index].key === this.role.key) {
        //     this.role.key = this.role.name.toLowerCase()
        //     this.rolesList.splice(index, 1, Object.assign({}, this.role))
        //     break
        //   }
        // }
      } else {
        const { data } = await addUser(this.user)
        // this.role.key = data.key
        // this.role.id = data.id
        this.usersList.push(data)
      }

      const { roleList, lpar, username } = this.user
      this.dialogVisible = false
      this.$notify({
        title: 'Success',
        dangerouslyUseHTMLString: true,
        message: `
            <div>User Name: ${username}</div>
            <div>LPAR: ${lpar}</div>
            <div>Roles: ${roleList}</div>
          `,
        type: 'success'
      })
    },
    // reference: src/view/layout/components/Sidebar/SidebarItem.vue
    onlyOneShowingChild(children = [], parent) {
      let onlyOneChild = null
      const showingChildren = children.filter(item => !item.hidden)

      // When there is only one child route, the child route is displayed by default
      if (showingChildren.length === 1) {
        onlyOneChild = showingChildren[0]
        onlyOneChild.path = path.resolve(parent.path, onlyOneChild.path)
        return onlyOneChild
      }

      // Show parent if there are no child route to display
      if (showingChildren.length === 0) {
        onlyOneChild = { ... parent, path: '', noShowingChildren: true }
        return onlyOneChild
      }

      return false
    }
  }
}
</script>

<style lang="scss" scoped>
.app-container {
  .roles-table {
    margin-top: 30px;
  }
  .permission-tree {
    margin-bottom: 30px;
  }
}
</style>
